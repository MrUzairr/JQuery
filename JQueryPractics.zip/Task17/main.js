$(document).ready(function(){
    //generate random color on click
    $(".generate-btn").click(function(){
        var randomColor = "";
        var characters = "0123456789abcdef";
        //loop to generate color randomly
        for(i=0;i<6;i++){
            randomColor = randomColor + characters[Math.floor(Math.random()*16)];
        }
        //add hex color code to input field
        $("#inputField").val("#"+randomColor);
        //change the text color of input field
        $("#inputField").css("color","#"+randomColor);
        //change the border color of input field
        $("#inputField").css("border-color","#"+randomColor);
        //change the div and copy button background color
        $(".color-preview,.copy-btn").css("background-color","#" + randomColor);
    })
    //create two functions to add and remove the animation class on alert-msg
    function add(){
        $(".alert-msg").addClass("slide-effect");
    }
    function remove(){
        $(".alert-msg").removeClass("slide-effect");
    }
    //copy color code on button click
    $(".copy-btn").click(function(){
        $("#inputField").select();
        document.execCommand("copy");

        //Call the function
        add();
        setTimeout(remove,2000);
        //set the span text equal to input field value
        $(".code").text($("#inputField").val());
    });
});