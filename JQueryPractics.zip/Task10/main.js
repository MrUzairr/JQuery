$(document).ready(function(){
    function add(){
        $('.copied').addClass("bounce-effect");
        $('.cut').addClass("bounce-effect");
    }
    function remove(){
        $('.copied').removeClass("bounce-effect");
        $('.cut').removeClass("bounce-effect");
    }
    $('.copy-btn').click(function(){
        $('#textField').select();
        document.execCommand("copy");
        add();
        setTimeout(remove,800);
    });
    $('.cut-btn').click(function(){
        $('#textField').select();
        document.execCommand("cut");
        add();
        setTimeout(remove,800);
    });
});